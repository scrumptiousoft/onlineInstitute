-- phpMyAdmin SQL Dump
-- version 2.8.0.1
-- http://www.phpmyadmin.net
-- 
-- Host: custsql-ipg56.eigbox.net
-- Generation Time: Jun 12, 2014 at 08:51 AM
-- Server version: 5.5.32
-- PHP Version: 4.4.9
-- 
-- Database: `designv`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `acos`
-- 

CREATE TABLE `acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=179 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=179 ;

-- 
-- Dumping data for table `acos`
-- 

INSERT INTO `acos` VALUES (1, NULL, '', NULL, 'controllers', 1, 352);
INSERT INTO `acos` VALUES (2, 1, '', NULL, 'Attachments', 2, 13);
INSERT INTO `acos` VALUES (3, 2, '', NULL, 'admin_index', 3, 4);
INSERT INTO `acos` VALUES (4, 2, '', NULL, 'admin_add', 5, 6);
INSERT INTO `acos` VALUES (5, 2, '', NULL, 'admin_edit', 7, 8);
INSERT INTO `acos` VALUES (6, 2, '', NULL, 'admin_delete', 9, 10);
INSERT INTO `acos` VALUES (7, 2, '', NULL, 'admin_browse', 11, 12);
INSERT INTO `acos` VALUES (8, 1, '', NULL, 'Blocks', 14, 29);
INSERT INTO `acos` VALUES (9, 8, '', NULL, 'admin_index', 15, 16);
INSERT INTO `acos` VALUES (10, 8, '', NULL, 'admin_add', 17, 18);
INSERT INTO `acos` VALUES (11, 8, '', NULL, 'admin_edit', 19, 20);
INSERT INTO `acos` VALUES (12, 8, '', NULL, 'admin_delete', 21, 22);
INSERT INTO `acos` VALUES (13, 8, '', NULL, 'admin_moveup', 23, 24);
INSERT INTO `acos` VALUES (14, 8, '', NULL, 'admin_movedown', 25, 26);
INSERT INTO `acos` VALUES (15, 8, '', NULL, 'admin_process', 27, 28);
INSERT INTO `acos` VALUES (16, 1, '', NULL, 'Comments', 30, 45);
INSERT INTO `acos` VALUES (17, 16, '', NULL, 'admin_index', 31, 32);
INSERT INTO `acos` VALUES (18, 16, '', NULL, 'admin_edit', 33, 34);
INSERT INTO `acos` VALUES (19, 16, '', NULL, 'admin_delete', 35, 36);
INSERT INTO `acos` VALUES (20, 16, '', NULL, 'admin_process', 37, 38);
INSERT INTO `acos` VALUES (21, 16, '', NULL, 'index', 39, 40);
INSERT INTO `acos` VALUES (22, 16, '', NULL, 'add', 41, 42);
INSERT INTO `acos` VALUES (23, 16, '', NULL, 'delete', 43, 44);
INSERT INTO `acos` VALUES (24, 1, '', NULL, 'Contacts', 46, 57);
INSERT INTO `acos` VALUES (25, 24, '', NULL, 'admin_index', 47, 48);
INSERT INTO `acos` VALUES (26, 24, '', NULL, 'admin_add', 49, 50);
INSERT INTO `acos` VALUES (27, 24, '', NULL, 'admin_edit', 51, 52);
INSERT INTO `acos` VALUES (28, 24, '', NULL, 'admin_delete', 53, 54);
INSERT INTO `acos` VALUES (29, 24, '', NULL, 'view', 55, 56);
INSERT INTO `acos` VALUES (30, 1, '', NULL, 'Filemanager', 58, 79);
INSERT INTO `acos` VALUES (31, 30, '', NULL, 'admin_index', 59, 60);
INSERT INTO `acos` VALUES (32, 30, '', NULL, 'admin_browse', 61, 62);
INSERT INTO `acos` VALUES (33, 30, '', NULL, 'admin_editfile', 63, 64);
INSERT INTO `acos` VALUES (34, 30, '', NULL, 'admin_upload', 65, 66);
INSERT INTO `acos` VALUES (35, 30, '', NULL, 'admin_delete_file', 67, 68);
INSERT INTO `acos` VALUES (36, 30, '', NULL, 'admin_delete_directory', 69, 70);
INSERT INTO `acos` VALUES (37, 30, '', NULL, 'admin_rename', 71, 72);
INSERT INTO `acos` VALUES (38, 30, '', NULL, 'admin_create_directory', 73, 74);
INSERT INTO `acos` VALUES (39, 30, '', NULL, 'admin_create_file', 75, 76);
INSERT INTO `acos` VALUES (40, 30, '', NULL, 'admin_chmod', 77, 78);
INSERT INTO `acos` VALUES (41, 1, '', NULL, 'Languages', 80, 95);
INSERT INTO `acos` VALUES (42, 41, '', NULL, 'admin_index', 81, 82);
INSERT INTO `acos` VALUES (43, 41, '', NULL, 'admin_add', 83, 84);
INSERT INTO `acos` VALUES (44, 41, '', NULL, 'admin_edit', 85, 86);
INSERT INTO `acos` VALUES (45, 41, '', NULL, 'admin_delete', 87, 88);
INSERT INTO `acos` VALUES (46, 41, '', NULL, 'admin_moveup', 89, 90);
INSERT INTO `acos` VALUES (47, 41, '', NULL, 'admin_movedown', 91, 92);
INSERT INTO `acos` VALUES (48, 41, '', NULL, 'admin_select', 93, 94);
INSERT INTO `acos` VALUES (49, 1, '', NULL, 'Links', 96, 111);
INSERT INTO `acos` VALUES (50, 49, '', NULL, 'admin_index', 97, 98);
INSERT INTO `acos` VALUES (51, 49, '', NULL, 'admin_add', 99, 100);
INSERT INTO `acos` VALUES (52, 49, '', NULL, 'admin_edit', 101, 102);
INSERT INTO `acos` VALUES (53, 49, '', NULL, 'admin_delete', 103, 104);
INSERT INTO `acos` VALUES (54, 49, '', NULL, 'admin_moveup', 105, 106);
INSERT INTO `acos` VALUES (55, 49, '', NULL, 'admin_movedown', 107, 108);
INSERT INTO `acos` VALUES (56, 49, '', NULL, 'admin_process', 109, 110);
INSERT INTO `acos` VALUES (57, 1, '', NULL, 'Menus', 112, 121);
INSERT INTO `acos` VALUES (58, 57, '', NULL, 'admin_index', 113, 114);
INSERT INTO `acos` VALUES (59, 57, '', NULL, 'admin_add', 115, 116);
INSERT INTO `acos` VALUES (60, 57, '', NULL, 'admin_edit', 117, 118);
INSERT INTO `acos` VALUES (61, 57, '', NULL, 'admin_delete', 119, 120);
INSERT INTO `acos` VALUES (62, 1, '', NULL, 'Messages', 122, 131);
INSERT INTO `acos` VALUES (63, 62, '', NULL, 'admin_index', 123, 124);
INSERT INTO `acos` VALUES (64, 62, '', NULL, 'admin_edit', 125, 126);
INSERT INTO `acos` VALUES (65, 62, '', NULL, 'admin_delete', 127, 128);
INSERT INTO `acos` VALUES (66, 62, '', NULL, 'admin_process', 129, 130);
INSERT INTO `acos` VALUES (67, 1, '', NULL, 'Nodes', 132, 161);
INSERT INTO `acos` VALUES (68, 67, '', NULL, 'admin_index', 133, 134);
INSERT INTO `acos` VALUES (69, 67, '', NULL, 'admin_create', 135, 136);
INSERT INTO `acos` VALUES (70, 67, '', NULL, 'admin_add', 137, 138);
INSERT INTO `acos` VALUES (71, 67, '', NULL, 'admin_edit', 139, 140);
INSERT INTO `acos` VALUES (72, 67, '', NULL, 'admin_update_paths', 141, 142);
INSERT INTO `acos` VALUES (73, 67, '', NULL, 'admin_delete', 143, 144);
INSERT INTO `acos` VALUES (74, 67, '', NULL, 'admin_delete_meta', 145, 146);
INSERT INTO `acos` VALUES (75, 67, '', NULL, 'admin_add_meta', 147, 148);
INSERT INTO `acos` VALUES (76, 67, '', NULL, 'admin_process', 149, 150);
INSERT INTO `acos` VALUES (77, 67, '', NULL, 'index', 151, 152);
INSERT INTO `acos` VALUES (78, 67, '', NULL, 'term', 153, 154);
INSERT INTO `acos` VALUES (79, 67, '', NULL, 'promoted', 155, 156);
INSERT INTO `acos` VALUES (80, 67, '', NULL, 'search', 157, 158);
INSERT INTO `acos` VALUES (81, 67, '', NULL, 'view', 159, 160);
INSERT INTO `acos` VALUES (82, 1, '', NULL, 'Regions', 162, 171);
INSERT INTO `acos` VALUES (83, 82, '', NULL, 'admin_index', 163, 164);
INSERT INTO `acos` VALUES (84, 82, '', NULL, 'admin_add', 165, 166);
INSERT INTO `acos` VALUES (85, 82, '', NULL, 'admin_edit', 167, 168);
INSERT INTO `acos` VALUES (86, 82, '', NULL, 'admin_delete', 169, 170);
INSERT INTO `acos` VALUES (87, 1, '', NULL, 'Roles', 172, 181);
INSERT INTO `acos` VALUES (88, 87, '', NULL, 'admin_index', 173, 174);
INSERT INTO `acos` VALUES (89, 87, '', NULL, 'admin_add', 175, 176);
INSERT INTO `acos` VALUES (90, 87, '', NULL, 'admin_edit', 177, 178);
INSERT INTO `acos` VALUES (91, 87, '', NULL, 'admin_delete', 179, 180);
INSERT INTO `acos` VALUES (92, 1, '', NULL, 'Settings', 182, 201);
INSERT INTO `acos` VALUES (93, 92, '', NULL, 'admin_dashboard', 183, 184);
INSERT INTO `acos` VALUES (94, 92, '', NULL, 'admin_index', 185, 186);
INSERT INTO `acos` VALUES (95, 92, '', NULL, 'admin_view', 187, 188);
INSERT INTO `acos` VALUES (96, 92, '', NULL, 'admin_add', 189, 190);
INSERT INTO `acos` VALUES (97, 92, '', NULL, 'admin_edit', 191, 192);
INSERT INTO `acos` VALUES (98, 92, '', NULL, 'admin_delete', 193, 194);
INSERT INTO `acos` VALUES (99, 92, '', NULL, 'admin_prefix', 195, 196);
INSERT INTO `acos` VALUES (100, 92, '', NULL, 'admin_moveup', 197, 198);
INSERT INTO `acos` VALUES (101, 92, '', NULL, 'admin_movedown', 199, 200);
INSERT INTO `acos` VALUES (102, 1, '', NULL, 'Terms', 202, 217);
INSERT INTO `acos` VALUES (103, 102, '', NULL, 'admin_index', 203, 204);
INSERT INTO `acos` VALUES (104, 102, '', NULL, 'admin_add', 205, 206);
INSERT INTO `acos` VALUES (105, 102, '', NULL, 'admin_edit', 207, 208);
INSERT INTO `acos` VALUES (106, 102, '', NULL, 'admin_delete', 209, 210);
INSERT INTO `acos` VALUES (107, 102, '', NULL, 'admin_moveup', 211, 212);
INSERT INTO `acos` VALUES (108, 102, '', NULL, 'admin_movedown', 213, 214);
INSERT INTO `acos` VALUES (109, 102, '', NULL, 'admin_process', 215, 216);
INSERT INTO `acos` VALUES (110, 1, '', NULL, 'Types', 218, 227);
INSERT INTO `acos` VALUES (111, 110, '', NULL, 'admin_index', 219, 220);
INSERT INTO `acos` VALUES (112, 110, '', NULL, 'admin_add', 221, 222);
INSERT INTO `acos` VALUES (113, 110, '', NULL, 'admin_edit', 223, 224);
INSERT INTO `acos` VALUES (114, 110, '', NULL, 'admin_delete', 225, 226);
INSERT INTO `acos` VALUES (115, 1, '', NULL, 'Users', 228, 261);
INSERT INTO `acos` VALUES (116, 115, '', NULL, 'admin_index', 229, 230);
INSERT INTO `acos` VALUES (117, 115, '', NULL, 'admin_add', 231, 232);
INSERT INTO `acos` VALUES (118, 115, '', NULL, 'admin_edit', 233, 234);
INSERT INTO `acos` VALUES (119, 115, '', NULL, 'admin_reset_password', 235, 236);
INSERT INTO `acos` VALUES (120, 115, '', NULL, 'admin_delete', 237, 238);
INSERT INTO `acos` VALUES (121, 115, '', NULL, 'admin_login', 239, 240);
INSERT INTO `acos` VALUES (122, 115, '', NULL, 'admin_logout', 241, 242);
INSERT INTO `acos` VALUES (123, 115, '', NULL, 'index', 243, 244);
INSERT INTO `acos` VALUES (124, 115, '', NULL, 'add', 245, 246);
INSERT INTO `acos` VALUES (125, 115, '', NULL, 'activate', 247, 248);
INSERT INTO `acos` VALUES (126, 115, '', NULL, 'edit', 249, 250);
INSERT INTO `acos` VALUES (127, 115, '', NULL, 'forgot', 251, 252);
INSERT INTO `acos` VALUES (128, 115, '', NULL, 'reset', 253, 254);
INSERT INTO `acos` VALUES (129, 115, '', NULL, 'login', 255, 256);
INSERT INTO `acos` VALUES (130, 115, '', NULL, 'logout', 257, 258);
INSERT INTO `acos` VALUES (131, 115, '', NULL, 'view', 259, 260);
INSERT INTO `acos` VALUES (132, 1, '', NULL, 'Vocabularies', 262, 271);
INSERT INTO `acos` VALUES (133, 132, '', NULL, 'admin_index', 263, 264);
INSERT INTO `acos` VALUES (134, 132, '', NULL, 'admin_add', 265, 266);
INSERT INTO `acos` VALUES (135, 132, '', NULL, 'admin_edit', 267, 268);
INSERT INTO `acos` VALUES (136, 132, '', NULL, 'admin_delete', 269, 270);
INSERT INTO `acos` VALUES (137, 1, '', NULL, 'AclAcos', 272, 281);
INSERT INTO `acos` VALUES (138, 137, '', NULL, 'admin_index', 273, 274);
INSERT INTO `acos` VALUES (139, 137, '', NULL, 'admin_add', 275, 276);
INSERT INTO `acos` VALUES (140, 137, '', NULL, 'admin_edit', 277, 278);
INSERT INTO `acos` VALUES (141, 137, '', NULL, 'admin_delete', 279, 280);
INSERT INTO `acos` VALUES (142, 1, '', NULL, 'AclActions', 282, 295);
INSERT INTO `acos` VALUES (143, 142, '', NULL, 'admin_index', 283, 284);
INSERT INTO `acos` VALUES (144, 142, '', NULL, 'admin_add', 285, 286);
INSERT INTO `acos` VALUES (145, 142, '', NULL, 'admin_edit', 287, 288);
INSERT INTO `acos` VALUES (146, 142, '', NULL, 'admin_delete', 289, 290);
INSERT INTO `acos` VALUES (147, 142, '', NULL, 'admin_move', 291, 292);
INSERT INTO `acos` VALUES (148, 142, '', NULL, 'admin_generate', 293, 294);
INSERT INTO `acos` VALUES (149, 1, '', NULL, 'AclAros', 296, 305);
INSERT INTO `acos` VALUES (150, 149, '', NULL, 'admin_index', 297, 298);
INSERT INTO `acos` VALUES (151, 149, '', NULL, 'admin_add', 299, 300);
INSERT INTO `acos` VALUES (152, 149, '', NULL, 'admin_edit', 301, 302);
INSERT INTO `acos` VALUES (153, 149, '', NULL, 'admin_delete', 303, 304);
INSERT INTO `acos` VALUES (154, 1, '', NULL, 'AclPermissions', 306, 311);
INSERT INTO `acos` VALUES (155, 154, '', NULL, 'admin_index', 307, 308);
INSERT INTO `acos` VALUES (156, 154, '', NULL, 'admin_toggle', 309, 310);
INSERT INTO `acos` VALUES (159, 1, '', NULL, 'ExtensionsHooks', 312, 317);
INSERT INTO `acos` VALUES (160, 159, '', NULL, 'admin_index', 313, 314);
INSERT INTO `acos` VALUES (161, 159, '', NULL, 'admin_toggle', 315, 316);
INSERT INTO `acos` VALUES (162, 1, '', NULL, 'ExtensionsLocales', 318, 329);
INSERT INTO `acos` VALUES (163, 162, '', NULL, 'admin_index', 319, 320);
INSERT INTO `acos` VALUES (164, 162, '', NULL, 'admin_activate', 321, 322);
INSERT INTO `acos` VALUES (165, 162, '', NULL, 'admin_add', 323, 324);
INSERT INTO `acos` VALUES (166, 162, '', NULL, 'admin_edit', 325, 326);
INSERT INTO `acos` VALUES (167, 162, '', NULL, 'admin_delete', 327, 328);
INSERT INTO `acos` VALUES (168, 1, '', NULL, 'ExtensionsPlugins', 330, 337);
INSERT INTO `acos` VALUES (169, 168, '', NULL, 'admin_index', 331, 332);
INSERT INTO `acos` VALUES (170, 168, '', NULL, 'admin_add', 333, 334);
INSERT INTO `acos` VALUES (171, 168, '', NULL, 'admin_delete', 335, 336);
INSERT INTO `acos` VALUES (172, 1, '', NULL, 'ExtensionsThemes', 338, 351);
INSERT INTO `acos` VALUES (173, 172, '', NULL, 'admin_index', 339, 340);
INSERT INTO `acos` VALUES (174, 172, '', NULL, 'admin_activate', 341, 342);
INSERT INTO `acos` VALUES (175, 172, '', NULL, 'admin_add', 343, 344);
INSERT INTO `acos` VALUES (176, 172, '', NULL, 'admin_editor', 345, 346);
INSERT INTO `acos` VALUES (177, 172, '', NULL, 'admin_save', 347, 348);
INSERT INTO `acos` VALUES (178, 172, '', NULL, 'admin_delete', 349, 350);

-- --------------------------------------------------------

-- 
-- Table structure for table `aros`
-- 

CREATE TABLE `aros` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `parent_id` int(10) DEFAULT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `foreign_key` int(10) DEFAULT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lft` int(10) DEFAULT NULL,
  `rght` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=14 ;

-- 
-- Dumping data for table `aros`
-- 

INSERT INTO `aros` VALUES (1, NULL, 'Role', 1, '', 1, 4);
INSERT INTO `aros` VALUES (2, NULL, 'Role', 2, '', 5, 12);
INSERT INTO `aros` VALUES (5, 12, 'User', 1, '', 14, 15);
INSERT INTO `aros` VALUES (9, 2, 'User', 3, NULL, 6, 7);
INSERT INTO `aros` VALUES (10, 2, 'User', 4, NULL, 8, 9);
INSERT INTO `aros` VALUES (11, 2, 'User', 5, NULL, 10, 11);
INSERT INTO `aros` VALUES (12, NULL, 'Role', 6, NULL, 13, 16);
INSERT INTO `aros` VALUES (13, 1, 'User', 6, NULL, 2, 3);

-- --------------------------------------------------------

-- 
-- Table structure for table `aros_acos`
-- 

CREATE TABLE `aros_acos` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `aro_id` int(10) NOT NULL,
  `aco_id` int(10) NOT NULL,
  `_create` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_read` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_update` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `_delete` varchar(2) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=29 ;

-- 
-- Dumping data for table `aros_acos`
-- 

INSERT INTO `aros_acos` VALUES (1, 2, 23, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (2, 2, 22, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (3, 2, 21, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (6, 2, 29, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (8, 2, 77, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (9, 2, 78, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (10, 2, 79, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (11, 2, 80, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (12, 2, 81, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (18, 2, 123, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (21, 2, 126, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (25, 2, 130, '1', '1', '1', '1');
INSERT INTO `aros_acos` VALUES (26, 2, 131, '1', '1', '1', '1');

-- --------------------------------------------------------

-- 
-- Table structure for table `attendancs`
-- 

CREATE TABLE `attendancs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `attend` tinyint(1) NOT NULL DEFAULT '0',
  `coursedate_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `userstat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `attendancs`
-- 

INSERT INTO `attendancs` VALUES (2, 0, 4, 3, 4);
INSERT INTO `attendancs` VALUES (4, 1, 4, 4, 4);
INSERT INTO `attendancs` VALUES (5, 1, 2, 4, 2);
INSERT INTO `attendancs` VALUES (6, 1, 5, 6, 2);

-- --------------------------------------------------------

-- 
-- Table structure for table `authors`
-- 

CREATE TABLE `authors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(127) NOT NULL,
  `email` varchar(127) NOT NULL,
  `website` varchar(127) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `authors`
-- 

INSERT INTO `authors` VALUES (1, 'Janetta K', 'ravisrivastava@redchillimedia.net', 'www.aaa.com');

-- --------------------------------------------------------

-- 
-- Table structure for table `blocks`
-- 

CREATE TABLE `blocks` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `region_id` int(20) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `show_title` tinyint(1) NOT NULL DEFAULT '1',
  `class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `weight` int(11) DEFAULT NULL,
  `element` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci NOT NULL,
  `visibility_paths` text COLLATE utf8_unicode_ci NOT NULL,
  `visibility_php` text COLLATE utf8_unicode_ci NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

-- 
-- Dumping data for table `blocks`
-- 

INSERT INTO `blocks` VALUES (3, 8, 'About', 'about', 'This is the content of your block. Can be modified in admin panel.', 1, '', 1, 1, '', '', '', '', '', '2010-11-16 10:18:13', '2009-07-26 17:13:14');
INSERT INTO `blocks` VALUES (8, 4, 'Search', 'search', '', 0, '', 0, 2, 'search', '', '', '', '', '2010-12-21 10:29:23', '2009-12-20 03:07:27');
INSERT INTO `blocks` VALUES (6, 4, 'Blogroll', 'blogroll', '[menu:blogroll]', 1, '', 0, 4, '', '', '', '', '', '2010-12-21 10:29:34', '2009-09-12 23:33:27');
INSERT INTO `blocks` VALUES (7, 4, 'Categories', 'categories', '[vocabulary:categories type="blog"]', 1, '', 1, 3, '', '', '', '', '', '2009-12-20 03:07:36', '2009-10-03 16:52:50');
INSERT INTO `blocks` VALUES (9, 4, 'Recent Posts', 'recent_posts', '[node:recent_posts conditions="Node.type:blog" order="Node.id DESC" limit="5"]', 1, '', 1, 5, '', '', '', '', '', '2010-04-08 21:09:31', '2009-12-22 05:17:32');

-- --------------------------------------------------------

-- 
-- Table structure for table `books`
-- 

CREATE TABLE `books` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isbn` varchar(13) NOT NULL,
  `title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `books`
-- 

INSERT INTO `books` VALUES (1, 'aaa', 'bbb', 'dffdf.d\r\ndf', 1);
INSERT INTO `books` VALUES (2, 'sas', 'rer', 'dffdf.d\r\ndf', 1);

-- --------------------------------------------------------

-- 
-- Table structure for table `comments`
-- 

CREATE TABLE `comments` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `node_id` int(20) NOT NULL,
  `user_id` int(20) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `ip` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `rating` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `notify` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `comment_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'comment',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=10 ;

-- 
-- Dumping data for table `comments`
-- 

INSERT INTO `comments` VALUES (1, NULL, 1, 0, 'Mr Redchillimedia', 'info@redchillimedia.com', 'http://www.redchillimedia.com', '127.0.0.1', '', 'Hi, this is the first comment.', NULL, 1, 0, 'blog', 'comment', 1, 2, '2009-12-25 12:00:00', '2009-12-25 12:00:00');
INSERT INTO `comments` VALUES (2, NULL, 1, 0, 'rahul', 'rahul.9373@gmail.com', 'redchillimedia.com', '192.168.1.11', '', 'hello,\r\n\r\n Good thinking ....nice', NULL, 1, 0, 'blog', 'comment', 3, 4, '2010-10-20 12:59:01', '2010-10-20 12:59:01');
INSERT INTO `comments` VALUES (3, NULL, 9, 1, 'Administrator', 'you@your-site.com', '/about', '192.168.1.12', '', 'vbvnbvnbnbvn\r\n', NULL, 1, 0, 'blog', 'comment', 5, 6, '2010-11-12 10:42:24', '2010-11-12 10:42:24');
INSERT INTO `comments` VALUES (4, NULL, 12, 1, 'Administrator', 'you@your-site.com', '/about', '192.168.1.12', '', 'kkkkkk', NULL, 0, 0, 'blog', 'comment', 7, 8, '2010-11-12 11:27:25', '2010-11-12 11:19:58');
INSERT INTO `comments` VALUES (5, NULL, 24, 1, 'Administrator', 'you@your-site.com', '/about', '192.168.1.11', '', 'true', NULL, 1, 0, 'blog', 'comment', 9, 10, '2010-12-17 11:16:43', '2010-12-17 11:16:43');
INSERT INTO `comments` VALUES (6, NULL, 24, 0, 'asdasd', 'asdasd@sdfsd.com', 'asdds.com', '192.168.1.11', '', 'dyasjdadjajsdsad', NULL, 1, 0, 'blog', 'comment', 11, 12, '2010-12-20 11:30:01', '2010-12-20 11:30:01');
INSERT INTO `comments` VALUES (7, NULL, 24, 0, 'rohit', 'rohit@rohit.com', 'rohit.com', '192.168.1.11', '', 'hello', NULL, 1, 0, 'blog', 'comment', 13, 14, '2010-12-20 11:31:28', '2010-12-20 11:31:28');
INSERT INTO `comments` VALUES (8, NULL, 24, 1, 'Administrator', 'you@your-site.com', '/about', '192.168.1.10', '', 'sdfsdfdsf', NULL, 1, 0, 'blog', 'comment', 15, 16, '2010-12-21 05:00:29', '2010-12-21 04:59:39');
INSERT INTO `comments` VALUES (9, NULL, 24, 0, 'rohit', 'rahul@g.com', 'sfs.com', '192.168.1.10', '', 'dskjlflksdjfjsdjflksd', NULL, 1, 0, 'blog', 'comment', 17, 18, '2010-12-21 05:08:11', '2010-12-21 05:07:35');

-- --------------------------------------------------------

-- 
-- Table structure for table `contacts`
-- 

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `position` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `address2` text COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `postcode` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fax` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `message_status` tinyint(1) NOT NULL DEFAULT '1',
  `message_archive` tinyint(1) NOT NULL DEFAULT '1',
  `message_count` int(11) NOT NULL DEFAULT '0',
  `message_spam_protection` tinyint(1) NOT NULL DEFAULT '0',
  `message_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `message_notify` tinyint(1) NOT NULL DEFAULT '1',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  `new_capcha` int(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `contacts`
-- 

INSERT INTO `contacts` VALUES (2, 'Contact', 'contact', '', 'rahul', 'developer', 'rahul', 'hsdgfsd', 'delhi', 'dsfsd', '4234', '3245365456', '45645', 'you@your-site.com', 1, 1, 3, 0, 0, 1, 1, '2010-12-22 09:54:02', '2010-12-22 09:50:10', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `coursedates`
-- 

CREATE TABLE `coursedates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `course_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- 
-- Dumping data for table `coursedates`
-- 

INSERT INTO `coursedates` VALUES (5, 7, '2014-06-12 05:29:00');
INSERT INTO `coursedates` VALUES (2, 4, '2014-06-10 07:49:00');
INSERT INTO `coursedates` VALUES (4, 5, '2014-06-02 07:49:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `courses`
-- 

CREATE TABLE `courses` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `namec` varchar(255) NOT NULL,
  `user_id` int(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `courses`
-- 

INSERT INTO `courses` VALUES (1, 'java', 3);
INSERT INTO `courses` VALUES (2, '.net', 4);
INSERT INTO `courses` VALUES (5, 'cpp', 4);
INSERT INTO `courses` VALUES (4, 'c', 3);
INSERT INTO `courses` VALUES (6, 'css', 4);
INSERT INTO `courses` VALUES (7, 'cpp', 6);

-- --------------------------------------------------------

-- 
-- Table structure for table `galleries`
-- 

CREATE TABLE `galleries` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(255) NOT NULL,
  `status` int(13) NOT NULL,
  `order` int(13) NOT NULL,
  `image` varchar(255) NOT NULL,
  `node_id` int(11) NOT NULL DEFAULT '0',
  `gallery_type` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

-- 
-- Dumping data for table `galleries`
-- 

INSERT INTO `galleries` VALUES (1, 'My One', 1, 1, '', 0, 'page', 'ddddd');
INSERT INTO `galleries` VALUES (2, 'My Two', 1, 2, '', 0, 'page', '');
INSERT INTO `galleries` VALUES (3, 'My Three', 1, 3, '', 0, 'page', '');
INSERT INTO `galleries` VALUES (4, 'datatesting', 1, 7, '', 0, 'page', '');
INSERT INTO `galleries` VALUES (5, 'data', 1, 2, '', 0, 'gallery', 'A variation of the common lorem ipsum text has been used since at least the 1960s, and possibly since the sixteenth century,[1][2] to provide a filler text during typesetting.\r\n\r\nThe text is derived from sections 1.10.32-33 of Cicero''s De finibus bonorum et malorum (On the Ends of Goods and Evils, or alternatively [About] The Purposes of Good and Evil).[4] The original passage began: Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit (Translation: "Neither is there anyone who loves grief itself since it is grief and thus wants to obtain it"). It is not known exactly when the text acquired its current standard form; it may have been as late as the 1960s. The passage was discovered by Richard McClintock, a Latin scholar who is the publications director at Hampden-Sydney College in Virginia, by searching for citings of the rarely used Latin word "consectetur" in classical literature.[1][2]');
INSERT INTO `galleries` VALUES (6, 'delta', 1, 2, '', 0, 'gallery', '    But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?\r\n    [33] On the other hand, we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame belongs to those who fail in their duty through weakness of will, which is the same as saying through shrinking from toil and pain. These cases are perfectly simple and easy to distinguish. In a free hour, when our power of choice is untrammelled and when nothing prevents our being able to do what we like best, every pleasure is to be welcomed and every pain avoided. But in certain circumstances and owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted. The wise man therefore always holds in these matters to this principle of selection: he rejects pleasures to secure other greater pleasures, or else he endures pains to avoid worse pains.');
INSERT INTO `galleries` VALUES (7, 'delta1', 1, 3, '', 0, 'gallery', 'The test card usually has a set of line-up patterns to enable television cameras and receivers to be adjusted to show the picture correctly. (Compare with SMPTE color bars.) Most modern test cards include a set of calibrated color bars which will produce a characteristic pattern of "dot landings" on a vectorscope, allowing chroma and tint to be precisely adjusted between generations of videotape or network feeds. SMPTE bars—and several other test cards—include analog black (a flat waveform at 7.5 IRE, or the NTSC setup level), full white (100IRE), and a "sub-black", or "blacker-than-black" (at 0 IRE), which represents the lowest low-frequency transmission voltage permissible in NTSC broadcasts (though the negative excursions of the colourburst signal may go below 0 IRE). Between the colour bars and proper adjustment of brightness and contrast controls to the limits of perception of the first sub-black bar, an analogue receiver (or other equipment such as VTRs) can be adjusted to provide impressive fidelity. The most famous Test Card shown in the UK since 1967 and also shown in some other countries is Test Card F, which features a little girl (Carol Hersee) and a clown doll in a circle in the centre of the picture.');

-- --------------------------------------------------------

-- 
-- Table structure for table `i18n`
-- 

CREATE TABLE `i18n` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `locale` varchar(6) COLLATE utf8_unicode_ci NOT NULL,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` int(10) NOT NULL,
  `field` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `locale` (`locale`),
  KEY `model` (`model`),
  KEY `row_id` (`foreign_key`),
  KEY `field` (`field`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `i18n`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `images`
-- 

CREATE TABLE `images` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `image_url` varchar(255) NOT NULL,
  `image_title` varchar(255) NOT NULL,
  `image_description` text NOT NULL,
  `gallery_id` int(13) NOT NULL,
  `order` int(13) NOT NULL,
  `type` varchar(64) NOT NULL DEFAULT 'image',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

-- 
-- Dumping data for table `images`
-- 

INSERT INTO `images` VALUES (1, 'img/galleries/Amaryllis.jpg', 'Image One', 'Image One', 1, 1, 'image');
INSERT INTO `images` VALUES (4, 'img/videos/Horse-3.flv', 'Video One', 'Video One', 1, 2, 'video');
INSERT INTO `images` VALUES (5, 'img/galleries/5independence-day-wallpaper-02.jpg', 'Image One', 'Image One', 2, 1, 'image');
INSERT INTO `images` VALUES (6, 'img/galleries/contact.jpg', 'Image Two', 'Image Two', 2, 2, 'image');
INSERT INTO `images` VALUES (7, 'img/galleries/home_image2.jpg', 'Image Three', 'Image Three', 2, 3, 'image');
INSERT INTO `images` VALUES (8, 'img/galleries/Move2.jpg', 'Image Four', 'Image Four', 2, 4, 'image');
INSERT INTO `images` VALUES (9, 'img/galleries/5independence-day-wallpaper-02.jpg', 'Image Two', 'Image Two', 1, 2, 'image');
INSERT INTO `images` VALUES (10, 'img/galleries/gascoines_map_with_paths_v2.jpg', 'Image Three', 'Image Three', 1, 3, 'image');
INSERT INTO `images` VALUES (11, 'img/galleries/Move1.jpg', 'Image Four', 'Image Four', 1, 4, 'image');
INSERT INTO `images` VALUES (12, 'img/galleries/5independence-day-wallpaper-02.jpg', 'Image One', 'Image One', 3, 1, 'image');
INSERT INTO `images` VALUES (13, 'img/galleries/Moving_and_labour_services.jpg', 'Image Two', 'Image Two', 3, 2, 'image');
INSERT INTO `images` VALUES (14, 'img/galleries/roses.jpg', 'Image Three', 'Image Three', 3, 3, 'image');
INSERT INTO `images` VALUES (15, 'img/galleries/Om.jpg', 'Image Four', 'Image Four', 3, 4, 'image');
INSERT INTO `images` VALUES (16, 'img/videos/Horse-2.flv', 'Video One', 'Video One', 3, 1, 'video');
INSERT INTO `images` VALUES (17, 'img/videos/Horse-3.flv', 'Video Two', 'Video Two', 3, 2, 'video');
INSERT INTO `images` VALUES (18, 'img/videos/Horse-4.flv', 'Video Three', 'Video Three', 3, 3, 'video');
INSERT INTO `images` VALUES (19, 'img/videos/Horse-3.flv', 'Video Two', 'Video Two', 1, 2, 'video');
INSERT INTO `images` VALUES (20, 'img/videos/Horse-4.flv', 'Video Three', 'Video Three', 1, 3, 'video');
INSERT INTO `images` VALUES (21, 'img/galleries/chip.jpg', 'test1', 'test1', 5, 0, 'image');
INSERT INTO `images` VALUES (22, 'img/galleries/biba.jpg', 'test2', 'test2', 5, 1, 'image');
INSERT INTO `images` VALUES (23, 'img/galleries/Blue_hills.jpg', 'test3', 'test3', 5, 3, 'image');
INSERT INTO `images` VALUES (24, 'img/galleries/Sunset.jpg', 'test4', 'test4', 5, 5, 'image');
INSERT INTO `images` VALUES (25, 'img/galleries/Sunset.jpg', 'test6', 'test6', 5, 5, 'image');
INSERT INTO `images` VALUES (26, 'img/galleries/Sunset.jpg', 'testN', 'testn', 5, 6, 'image');
INSERT INTO `images` VALUES (27, 'img/galleries/head.jpg', 'dataN', 'dataN', 5, 7, 'image');
INSERT INTO `images` VALUES (28, 'img/galleries/icon.jpg', 'dataV1', 'Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.', 5, 8, 'image');
INSERT INTO `images` VALUES (29, 'img/galleries/footer-bg.jpg', 'datavvv', ' 	  Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.', 5, 9, 'image');
INSERT INTO `images` VALUES (30, 'img/galleries/aaaaaaaaaaaaaaa.jpg', 'test11', 'Even though using "lorem ipsum" often arouses curiosity because of its resemblance t', 5, 8, 'image');
INSERT INTO `images` VALUES (31, 'img/galleries/call_of_duty.jpg', 'tets12', 't is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', 5, 9, 'image');
INSERT INTO `images` VALUES (32, 'img/galleries/imgCall_of_Duty_Modern_Warfare_24.jpg', 'tte14', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', 5, 10, 'image');
INSERT INTO `images` VALUES (33, 'img/galleries/imgCall_of_Duty_Modern_Warfare_24.jpg', 'testImage', 'testImage', 6, 1, 'image');
INSERT INTO `images` VALUES (34, 'img/galleries/call_of_duty.jpg', 'testImage1', 'testImage1', 6, 2, 'image');

-- --------------------------------------------------------

-- 
-- Table structure for table `languages`
-- 

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `native` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Dumping data for table `languages`
-- 

INSERT INTO `languages` VALUES (1, 'English', 'English', 'eng', 1, 1, '2009-11-02 21:37:38', '2009-11-02 20:52:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `links`
-- 

CREATE TABLE `links` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `menu_id` int(20) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `target` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=34 ;

-- 
-- Dumping data for table `links`
-- 

INSERT INTO `links` VALUES (5, NULL, 4, 'Home', '', '/', '', '', 1, 3, 4, '["3"]', '', '2010-12-16 11:24:04', '2009-08-19 12:23:33');
INSERT INTO `links` VALUES (6, NULL, 4, 'About Us', '', 'controller:contacts/action:view/contact', '', '', 1, 5, 6, '', '', '2010-12-16 11:24:18', '2009-08-19 12:34:56');
INSERT INTO `links` VALUES (7, NULL, 3, 'Home', '', '/', '', '', 1, 5, 6, '', '', '2010-11-12 10:48:01', '2009-09-06 21:32:54');
INSERT INTO `links` VALUES (8, NULL, 3, 'About Us', '', 'controller:nodes/action:view/type:page/slug:about', '', '', 1, 7, 8, '', '', '2010-12-17 06:51:39', '2009-09-06 21:34:57');
INSERT INTO `links` VALUES (18, NULL, 7, 'dgfdfgd', '', 'controller:nodes/action:view/type:page/slug:about', '', '', 1, 1, 2, '["3"]', '', '2010-10-20 13:24:51', '2010-10-20 13:20:57');
INSERT INTO `links` VALUES (10, NULL, 5, 'Site Admin', '', '/admin', '', '', 1, 1, 2, '', '', '2009-09-12 06:34:09', '2009-09-12 06:34:09');
INSERT INTO `links` VALUES (11, NULL, 5, 'Log out', '', '/users/logout', '', '', 1, 7, 8, '["1","2"]', '', '2009-09-12 06:35:22', '2009-09-12 06:34:41');
INSERT INTO `links` VALUES (12, NULL, 6, 'Redchillimedia', '', 'http://www.redchillimedia.com', '', '', 1, 3, 4, '', '', '2009-09-12 23:31:59', '2009-09-12 23:31:59');
INSERT INTO `links` VALUES (14, NULL, 6, 'CakePHP', '', 'http://www.cakephp.org', '', '', 1, 1, 2, '', '', '2009-10-07 03:25:25', '2009-09-12 23:38:43');
INSERT INTO `links` VALUES (15, NULL, 3, 'Blog', '', 'controller:nodes/action:view/type:blog/slug:who-is-rahul', '', '', 1, 17, 18, '', '', '2010-12-17 11:25:57', '2009-09-16 07:53:33');
INSERT INTO `links` VALUES (16, NULL, 5, 'Entries (RSS)', '', '/nodes/promoted.rss', '', '', 1, 3, 4, '', '', '2009-10-27 17:46:22', '2009-10-27 17:46:22');
INSERT INTO `links` VALUES (17, NULL, 5, 'Comments (RSS)', '', '/comments.rss', '', '', 1, 5, 6, '', '', '2009-10-27 17:46:54', '2009-10-27 17:46:54');
INSERT INTO `links` VALUES (23, NULL, 3, 'Testimonials', '', 'controller:nodes/action:view/type:page/slug:testimonial', '', '', 1, 13, 14, '', '', '2010-12-17 09:41:39', '2010-11-02 11:14:01');
INSERT INTO `links` VALUES (20, NULL, 3, 'Gallery', '', 'controller:nodes/action:view/type:page/slug:gallery', '', '', 1, 9, 10, '', '', '2010-12-17 11:37:15', '2010-10-27 07:13:23');
INSERT INTO `links` VALUES (25, NULL, 3, 'Contact Us', '', 'controller:nodes/action:view/type:page/slug:contact', '', '', 1, 15, 16, '', '', '2010-12-22 09:10:09', '2010-11-02 11:58:04');
INSERT INTO `links` VALUES (26, NULL, 4, 'Gallery', '', 'controller:nodes/action:view/type:page/slug:test', '', '', 1, 7, 8, '', '', '2010-12-16 11:24:42', '2010-11-12 10:57:47');
INSERT INTO `links` VALUES (29, NULL, 4, 'Partners', '', 'controller:nodes/action:view/type:blog/slug:testing', '', '', 1, 9, 10, '', '', '2010-12-16 11:25:11', '2010-12-16 11:25:02');
INSERT INTO `links` VALUES (30, NULL, 4, 'Testimonials', '', 'controller:nodes/action:view/type:blog/slug:xyz', '', '', 1, 11, 12, '', '', '2010-12-16 11:25:38', '2010-12-16 11:25:38');
INSERT INTO `links` VALUES (31, NULL, 4, 'Contact Us', '', 'controller:nodes/action:view/type:blog/slug:xyz', '', '', 1, 13, 14, '', '', '2010-12-16 11:25:58', '2010-12-16 11:25:58');
INSERT INTO `links` VALUES (32, NULL, 4, 'Blog', '', 'controller:nodes/action:view/type:blog/slug:testing', '', '', 1, 15, 16, '', '', '2010-12-16 11:26:13', '2010-12-16 11:26:13');
INSERT INTO `links` VALUES (33, NULL, 3, 'Partners', '', 'controller:nodes/action:view/type:page/slug:partners', '', '', 1, 11, 12, '', '', '2010-12-17 09:41:28', '2010-12-16 12:13:44');

-- --------------------------------------------------------

-- 
-- Table structure for table `menus`
-- 

CREATE TABLE `menus` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `link_count` int(11) NOT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

-- 
-- Dumping data for table `menus`
-- 

INSERT INTO `menus` VALUES (3, 'Main Menu', 'main', '', 1, NULL, 7, '', '2009-08-19 12:21:06', '2009-07-22 01:49:53');
INSERT INTO `menus` VALUES (4, 'Footer', 'footer', '', 1, NULL, 7, '', '2009-08-19 12:22:42', '2009-08-19 12:22:42');

-- --------------------------------------------------------

-- 
-- Table structure for table `messages`
-- 

CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `address` text COLLATE utf8_unicode_ci NOT NULL,
  `message_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `messages`
-- 

INSERT INTO `messages` VALUES (4, 2, 'rohit', 'rahul.9373@gmail.com', 'kalkaji', 'hello', '', '989898989898', '', NULL, 0, '2010-12-22 10:54:59', '2010-12-22 10:54:59');
INSERT INTO `messages` VALUES (5, 2, 'rohit', 'rahul.9373@gmail.com', '', 'hello,\r\n\r\nI am rahul srivastava.\r\n\r\nthanks\r\nrahul', '', '9898989898', 'govindpuri,kalkaji(new delhi)', NULL, 1, '2010-12-22 10:57:29', '2010-12-22 10:57:29');
INSERT INTO `messages` VALUES (6, 2, 'rahul', 'rahul.9373@gmail.com', '', 'hello', '', '98989898978', 'kalkaji', NULL, 0, '2010-12-22 10:58:36', '2010-12-22 10:58:36');

-- --------------------------------------------------------

-- 
-- Table structure for table `meta`
-- 

CREATE TABLE `meta` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `model` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Node',
  `foreign_key` int(20) DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=31 ;

-- 
-- Dumping data for table `meta`
-- 

INSERT INTO `meta` VALUES (1, 'Node', 1, 'meta_keywords', 'key1, key2', NULL);
INSERT INTO `meta` VALUES (2, 'Node', 3, '', '', NULL);
INSERT INTO `meta` VALUES (3, 'Node', 4, '', '', NULL);
INSERT INTO `meta` VALUES (4, 'Node', 5, '', '', NULL);
INSERT INTO `meta` VALUES (5, 'Node', 6, '', '', NULL);
INSERT INTO `meta` VALUES (6, 'Node', 7, '', '', NULL);
INSERT INTO `meta` VALUES (7, 'Node', 8, '', '', NULL);
INSERT INTO `meta` VALUES (8, 'Node', 9, '', '', NULL);
INSERT INTO `meta` VALUES (9, 'Node', 10, '', '', NULL);
INSERT INTO `meta` VALUES (10, 'Node', 11, '', '', NULL);
INSERT INTO `meta` VALUES (11, 'Node', 12, '', '', NULL);
INSERT INTO `meta` VALUES (12, 'Node', 13, '', '', NULL);
INSERT INTO `meta` VALUES (13, 'Node', 17, '', '', NULL);
INSERT INTO `meta` VALUES (14, 'Node', 18, '', '', NULL);
INSERT INTO `meta` VALUES (15, 'Node', 19, '', '', NULL);
INSERT INTO `meta` VALUES (16, 'Node', 20, '', '', NULL);
INSERT INTO `meta` VALUES (17, 'Node', 21, '', '', NULL);
INSERT INTO `meta` VALUES (18, 'Node', 22, '', '', NULL);
INSERT INTO `meta` VALUES (19, 'Node', 23, '', '', NULL);
INSERT INTO `meta` VALUES (20, 'Node', 24, '', '', NULL);
INSERT INTO `meta` VALUES (21, 'Node', 25, '', '', NULL);
INSERT INTO `meta` VALUES (22, 'Node', 26, '', '', NULL);
INSERT INTO `meta` VALUES (23, 'Node', 27, '', '', NULL);
INSERT INTO `meta` VALUES (24, 'Node', 28, '', '', NULL);
INSERT INTO `meta` VALUES (25, 'Node', 29, '', '', NULL);
INSERT INTO `meta` VALUES (26, 'Node', 30, '', '', NULL);
INSERT INTO `meta` VALUES (27, 'Node', 31, '', '', NULL);
INSERT INTO `meta` VALUES (28, 'Node', 32, '', '', NULL);
INSERT INTO `meta` VALUES (29, 'Node', 33, '', '', NULL);
INSERT INTO `meta` VALUES (30, 'Node', 34, '', '', NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `newsletters`
-- 

CREATE TABLE `newsletters` (
  `id` int(64) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `add_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `newsletters`
-- 

INSERT INTO `newsletters` VALUES (1, 'aaa@aa.com', '2010-11-30');
INSERT INTO `newsletters` VALUES (2, 'bb@bb.com', '2010-11-30');

-- --------------------------------------------------------

-- 
-- Table structure for table `nodes`
-- 

CREATE TABLE `nodes` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `user_id` int(20) NOT NULL DEFAULT '0',
  `gallery_id` int(11) DEFAULT '0',
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `comment_status` int(1) NOT NULL DEFAULT '1',
  `comment_count` int(11) DEFAULT '0',
  `promote` tinyint(1) NOT NULL DEFAULT '0',
  `path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `terms` text COLLATE utf8_unicode_ci NOT NULL,
  `sticky` tinyint(1) NOT NULL DEFAULT '0',
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  `visibility_roles` text COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'node',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=35 ;

-- 
-- Dumping data for table `nodes`
-- 

INSERT INTO `nodes` VALUES (15, NULL, 0, 0, 'Blue hills', 'Blue hills.jpg', '', '', 0, 'image/jpeg', 1, 0, 0, '/uploads/Blue hills.jpg', '', 0, 1, 2, '', 'attachment', '2010-11-13 10:30:41', '2010-11-13 10:30:41');
INSERT INTO `nodes` VALUES (14, NULL, 0, 0, 'Sunset', 'Sunset.jpg', '', '', 0, 'image/jpeg', 1, 0, 0, '/uploads/Sunset.jpg', '', 0, 1, 2, '', 'attachment', '2010-11-13 10:29:14', '2010-11-13 10:29:14');
INSERT INTO `nodes` VALUES (16, NULL, 0, 0, 'Water lilies', 'Water lilies.jpg', '', '', 0, 'image/jpeg', 1, 0, 0, '/uploads/Water lilies.jpg', '', 0, 1, 2, '', 'attachment', '2010-11-13 10:30:48', '2010-11-13 10:30:48');
INSERT INTO `nodes` VALUES (18, NULL, 1, 2, 'about', 'about', '<p><strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n<div class="rc">\r\n<h2 class="why"><span>Why do we use it?</span></h2>\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for ''lorem ipsum'' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>', 'about', 1, '', 1, 0, 0, '/about', '', 0, 1, 2, '', 'page', '2010-12-22 07:48:02', '2010-12-16 12:21:00');
INSERT INTO `nodes` VALUES (19, NULL, 1, 1, 'home', 'home', '<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>\r\n<p>The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.</p>', 'home', 1, '', 1, 0, 1, '/page/home', '', 0, 1, 2, '', 'page', '2010-12-16 13:26:52', '2010-12-16 12:23:00');
INSERT INTO `nodes` VALUES (23, NULL, 1, NULL, 'Contact', 'contact', '<p>[Contact]</p>', 'contact', 1, '', 1, 0, 0, '/page/contact', '', 0, 1, 2, '', 'page', '2010-12-22 07:50:16', '2010-12-17 10:08:00');
INSERT INTO `nodes` VALUES (20, NULL, 1, 1, 'Partners', 'partners', '\r\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.', 'partners', 1, '', 1, 0, 0, '/page/partners', '', 0, 1, 2, '', 'page', '2014-06-06 07:40:14', '2010-12-16 12:24:00');
INSERT INTO `nodes` VALUES (21, NULL, 1, 1, 'Testimonial', 'testimonial', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry''s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.', 'testimonial', 1, '', 1, 0, 0, '/page/testimonial', '', 0, 1, 2, '', 'page', '2014-06-06 07:36:10', '2010-12-16 12:24:00');
INSERT INTO `nodes` VALUES (25, NULL, 1, 1, 'gallery', 'gallery', '<p>fsdfsdfds</p>', 'fdgdfg', 1, '', 1, 0, 0, '/page/gallery', '', 0, 1, 2, '', 'page', '2010-12-17 11:38:36', '2010-12-17 11:36:00');
INSERT INTO `nodes` VALUES (34, NULL, 1, 0, 'test12', 'test12', 'There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don''t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn''t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.', '', 1, '', 2, 0, 1, '/blog/test12', '', 0, 1, 2, '', 'blog', '2014-06-06 07:45:16', '2014-06-06 07:44:00');
INSERT INTO `nodes` VALUES (33, NULL, 1, 3, 'test', 'test', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using ''Content here, content here'', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for ''lorem ipsum'' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '', 1, '', 1, 0, 0, '/page/test', '', 0, 1, 2, '', 'page', '2014-06-06 07:37:12', '2010-12-22 12:00:00');

-- --------------------------------------------------------

-- 
-- Table structure for table `nodes_taxonomies`
-- 

CREATE TABLE `nodes_taxonomies` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `node_id` int(20) NOT NULL DEFAULT '0',
  `taxonomy_id` int(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=25 ;

-- 
-- Dumping data for table `nodes_taxonomies`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `regions`
-- 

CREATE TABLE `regions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `block_count` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

-- 
-- Dumping data for table `regions`
-- 

INSERT INTO `regions` VALUES (3, 'none', '', '', 0);
INSERT INTO `regions` VALUES (4, 'right', 'right', '', 2);
INSERT INTO `regions` VALUES (6, 'left', 'left', '', 0);
INSERT INTO `regions` VALUES (7, 'header', 'header', '', 0);
INSERT INTO `regions` VALUES (8, 'footer', 'footer', '', 1);
INSERT INTO `regions` VALUES (9, 'region1', 'region1', '', 0);
INSERT INTO `regions` VALUES (10, 'region2', 'region2', '', 0);
INSERT INTO `regions` VALUES (11, 'region3', 'region3', '', 0);
INSERT INTO `regions` VALUES (12, 'region4', 'region4', '', 0);
INSERT INTO `regions` VALUES (13, 'region5', 'region5', '', 0);
INSERT INTO `regions` VALUES (14, 'region6', 'region6', '', 0);
INSERT INTO `regions` VALUES (15, 'region7', 'region7', '', 0);
INSERT INTO `regions` VALUES (16, 'region8', 'region8', '', 0);
INSERT INTO `regions` VALUES (17, 'region9', 'region9', '', 0);

-- --------------------------------------------------------

-- 
-- Table structure for table `roles`
-- 

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `roles`
-- 

INSERT INTO `roles` VALUES (1, 'Teacher', 'teacher', '2009-04-05 00:10:34', '2014-06-11 07:46:59');
INSERT INTO `roles` VALUES (2, 'Student', 'student', '2009-04-05 00:10:50', '2014-06-11 02:00:42');
INSERT INTO `roles` VALUES (6, 'system admin', 'system admin', '2014-06-12 05:22:30', '2014-06-12 05:22:30');

-- --------------------------------------------------------

-- 
-- Table structure for table `settings`
-- 

CREATE TABLE `settings` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `input_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'text',
  `editable` tinyint(1) NOT NULL DEFAULT '1',
  `weight` int(11) DEFAULT NULL,
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=33 ;

-- 
-- Dumping data for table `settings`
-- 

INSERT INTO `settings` VALUES (6, 'Site.title', 'demo', '', '', '', 1, 1, '');
INSERT INTO `settings` VALUES (7, 'Site.tagline', 'demo cake system', '', '', 'textarea', 1, 2, '');
INSERT INTO `settings` VALUES (8, 'Site.email', 'rahul.9373@gmail.com', '', '', '', 1, 3, '');
INSERT INTO `settings` VALUES (9, 'Site.status', '1', '', '', 'checkbox', 1, 5, '');
INSERT INTO `settings` VALUES (12, 'Meta.robots', 'index, follow', '', '', '', 1, 6, '');
INSERT INTO `settings` VALUES (13, 'Meta.keywords', 'demo cake', '', '', 'textarea', 1, 7, '');
INSERT INTO `settings` VALUES (14, 'Meta.description', 'demo cake', '', '', 'textarea', 1, 8, '');
INSERT INTO `settings` VALUES (15, 'Meta.generator', 'Redchillimedia - Content Management System', '', '', '', 0, 9, '');
INSERT INTO `settings` VALUES (16, 'Service.akismet_key', 'gfdfgdf', '', '', '', 1, 11, '');
INSERT INTO `settings` VALUES (17, 'Service.recaptcha_public_key', 'gdfgdfgdf', '', '', '', 1, 12, '');
INSERT INTO `settings` VALUES (18, 'Service.recaptcha_private_key', 'fdgdfgdfg', '', '', '', 1, 13, '');
INSERT INTO `settings` VALUES (19, 'Service.akismet_url', 'http://www.scrumptioussoftsolutions.com/', '', '', '', 1, 10, '');
INSERT INTO `settings` VALUES (20, 'Site.theme', '', '', '', '', 0, 14, '');
INSERT INTO `settings` VALUES (21, 'Site.feed_url', '', '', '', '', 0, 15, '');
INSERT INTO `settings` VALUES (22, 'Reading.nodes_per_page', '5', '', '', '', 1, 16, '');
INSERT INTO `settings` VALUES (23, 'Writing.wysiwyg', '1', 'Enable WYSIWYG editor', '', 'checkbox', 1, 17, '');
INSERT INTO `settings` VALUES (24, 'Comment.level', '1', '', 'levels deep (threaded comments)', '', 1, 18, '');
INSERT INTO `settings` VALUES (25, 'Comment.feed_limit', '10', '', 'number of comments to show in feed', '', 1, 19, '');
INSERT INTO `settings` VALUES (26, 'Site.locale', 'eng', '', '', 'text', 0, 20, '');
INSERT INTO `settings` VALUES (27, 'Reading.date_time_format', 'D, M d Y H:i:s', '', '', '', 1, 21, '');
INSERT INTO `settings` VALUES (28, 'Comment.date_time_format', 'M d, Y', '', '', '', 1, 22, '');
INSERT INTO `settings` VALUES (29, 'Site.timezone', '0', '', 'zero (0) for GMT', '', 1, 4, '');
INSERT INTO `settings` VALUES (32, 'Hook.bootstraps', 'tinymce', '', '', '', 0, 23, '');

-- --------------------------------------------------------

-- 
-- Table structure for table `taxonomies`
-- 

CREATE TABLE `taxonomies` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `parent_id` int(20) DEFAULT NULL,
  `term_id` int(10) NOT NULL,
  `vocabulary_id` int(10) NOT NULL,
  `lft` int(11) DEFAULT NULL,
  `rght` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `taxonomies`
-- 

INSERT INTO `taxonomies` VALUES (1, NULL, 1, 1, 1, 2);
INSERT INTO `taxonomies` VALUES (2, NULL, 2, 1, 3, 4);
INSERT INTO `taxonomies` VALUES (3, NULL, 3, 2, 1, 2);
INSERT INTO `taxonomies` VALUES (4, NULL, 4, 1, 5, 6);

-- --------------------------------------------------------

-- 
-- Table structure for table `terms`
-- 

CREATE TABLE `terms` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

-- 
-- Dumping data for table `terms`
-- 

INSERT INTO `terms` VALUES (1, 'Uncategorized', 'uncategorized', '', '2009-07-22 03:38:43', '2009-07-22 03:34:56');
INSERT INTO `terms` VALUES (2, 'Announcements', 'announcements', '', '2010-05-16 23:57:06', '2009-07-22 03:45:37');
INSERT INTO `terms` VALUES (3, 'mytag', 'mytag', '', '2009-08-26 14:42:43', '2009-08-26 14:42:43');
INSERT INTO `terms` VALUES (4, 'Student', 'student', 'Student detail', '2010-12-21 11:10:19', '2010-12-21 11:10:19');

-- --------------------------------------------------------

-- 
-- Table structure for table `types`
-- 

CREATE TABLE `types` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `format_show_author` tinyint(1) NOT NULL DEFAULT '1',
  `format_show_date` tinyint(1) NOT NULL DEFAULT '1',
  `comment_status` int(1) NOT NULL DEFAULT '1',
  `comment_approve` tinyint(1) NOT NULL DEFAULT '1',
  `comment_spam_protection` tinyint(1) NOT NULL DEFAULT '0',
  `comment_captcha` tinyint(1) NOT NULL DEFAULT '0',
  `params` text COLLATE utf8_unicode_ci NOT NULL,
  `plugin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `types`
-- 

INSERT INTO `types` VALUES (1, 'Page', 'page', 'A page is a simple method for creating and displaying information that rarely changes, such as an "About us" section of a website. By default, a page entry does not allow visitor comments.', 0, 0, 0, 1, 0, 0, '', '', '2009-09-09 00:23:24', '2009-09-02 18:06:27');
INSERT INTO `types` VALUES (2, 'Blog', 'blog', 'A blog entry is a single post to an online journal, or blog.', 1, 1, 2, 0, 0, 0, '', '', '2010-12-21 04:58:25', '2009-09-02 18:20:44');

-- --------------------------------------------------------

-- 
-- Table structure for table `types_vocabularies`
-- 

CREATE TABLE `types_vocabularies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `type_id` int(10) NOT NULL,
  `vocabulary_id` int(10) NOT NULL,
  `weight` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=36 ;

-- 
-- Dumping data for table `types_vocabularies`
-- 

INSERT INTO `types_vocabularies` VALUES (35, 2, 2, NULL);
INSERT INTO `types_vocabularies` VALUES (34, 2, 1, NULL);

-- --------------------------------------------------------

-- 
-- Table structure for table `users`
-- 

CREATE TABLE `users` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `website` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `activation_key` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bio` text COLLATE utf8_unicode_ci NOT NULL,
  `timezone` varchar(10) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `users`
-- 

INSERT INTO `users` VALUES (1, 6, 'admin', '5f24034a8a30e51474cee1425aa82fb60c47879d', 'Administrator', 'rahul.9373@gmail.com', '/about', '9de8d7d8438855f04fb4967465857ce2', '', '', '0', 1, '2014-06-12 05:23:01', '2009-04-05 00:20:34');
INSERT INTO `users` VALUES (3, 2, 'rahul', 'aaba61eecb9a511fde5d113dbf5d5510803310bc', 'rahul', 'rahul.92373@gmail.com', '', 'c85f94de7f4270749ca48f34179e3800', '', '', '0', 0, '2014-06-06 09:07:36', '2014-06-06 09:07:36');
INSERT INTO `users` VALUES (4, 2, 'shyam', '144451e185f09213efd7b79f4a8b2c8a41b72fbf', 'shyamender', 'shyam@abc.com', '', '725e9df4e70e7ebbaeaa8e9b13beba47', '', '', '0', 0, '2014-06-06 09:13:34', '2014-06-06 09:13:34');
INSERT INTO `users` VALUES (5, 2, 'naren', 'ed8a39b124372536a75373fdb5fb81476fc6c96b', 'narender', 'naren8687@gmail.com', 'www.abc.com', '45fbf83423d2245ce80980e0a6463623', '', '', '0', 1, '2014-06-11 06:10:41', '2014-06-11 06:10:22');
INSERT INTO `users` VALUES (6, 1, 'rama', 'ed8a39b124372536a75373fdb5fb81476fc6c96b', 'rama', 'rama@rama.com', 'www.rama.com', '5dd62899b2103d1b26a165d319ef8235', '', '', '0', 1, '2014-06-12 05:24:25', '2014-06-12 05:24:25');

-- --------------------------------------------------------

-- 
-- Table structure for table `userstats`
-- 

CREATE TABLE `userstats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `statusvalue` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

-- 
-- Dumping data for table `userstats`
-- 

INSERT INTO `userstats` VALUES (5, 'Absent', 4);
INSERT INTO `userstats` VALUES (2, 'Present', 3);
INSERT INTO `userstats` VALUES (6, 'Present', 6);
INSERT INTO `userstats` VALUES (4, 'start', 4);

-- --------------------------------------------------------

-- 
-- Table structure for table `videos`
-- 

CREATE TABLE `videos` (
  `id` int(13) NOT NULL AUTO_INCREMENT,
  `video_url` varchar(255) NOT NULL,
  `video_title` varchar(255) NOT NULL,
  `video_description` text NOT NULL,
  `gallery_id` int(13) NOT NULL,
  `order` int(13) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- 
-- Dumping data for table `videos`
-- 


-- --------------------------------------------------------

-- 
-- Table structure for table `vocabularies`
-- 

CREATE TABLE `vocabularies` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `description` text COLLATE utf8_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL DEFAULT '0',
  `multiple` tinyint(1) NOT NULL DEFAULT '0',
  `tags` tinyint(1) NOT NULL DEFAULT '0',
  `plugin` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `weight` int(11) DEFAULT NULL,
  `updated` datetime NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `alias` (`alias`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

-- 
-- Dumping data for table `vocabularies`
-- 

INSERT INTO `vocabularies` VALUES (1, 'Categories', 'categories', '', 0, 1, 0, '', 1, '2010-05-17 20:03:11', '2009-07-22 02:16:21');
INSERT INTO `vocabularies` VALUES (2, 'Tags', 'tags', '', 0, 1, 0, '', 2, '2010-05-17 20:03:11', '2009-07-22 02:16:34');
